/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.gome.task;

import com.bshg.task.APITask;
import com.bshg.gome.util.GomeXmlCreator;

/**
 *
 * @author admjingya
 */
public class GomeOrderConfirmTask extends APITask{
    
    private static final long TIME_INTERVAL = 24 * 60 * 60 * 1000;

    public GomeOrderConfirmTask(int hourOfDay, int minute, int second) {
        super(hourOfDay, minute, second, TIME_INTERVAL);
    }
    
    @Override
    public void run() {
        // query the orders whose status is "10"
        GomeXmlCreator.createOrderQueryXml("10");
    }
}
