/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.util;

import com.bshg.mapper.OrderItemMapper;
import com.bshg.mapper.SalesOrderMapper;
import com.bshg.model.OrderItem;
import com.bshg.model.SalesOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author admjingya
 */
@Slf4j
public class DBUtil {

    private static SqlSession session;

    public static void saveOrdersAndItems2DB(List<SalesOrder> orders, List<OrderItem> items) {
        if (orders.size() > 0) {
            try {
                session = MyBatisUtil.openSession();

                Map orderParams = new HashMap();
                orderParams.put("list", orders);

                session.getMapper(SalesOrderMapper.class).insertOrders(orderParams);
                for (OrderItem item : items) {
                    session.getMapper(OrderItemMapper.class).insertItem(item);
                }
                session.commit();
            } catch (Exception e) {
                session.rollback();
                log.error("Error in saving orders and items to DB.");
                EmailUtil.sendEmail("Scheduler API error", e.getMessage());
            } finally {
                MyBatisUtil.closeSession(session);
            }
        }
    }

    public static boolean checkDupOrder(String custCode, String orderNum) {
        try {
            session = MyBatisUtil.openSession();

            Map<String, String> params = new HashMap<>();
            params.put("custCode", custCode);
            params.put("orderNum", orderNum);

            return session.getMapper(SalesOrderMapper.class).getOrderByNum(params) == null;
        } finally {
            MyBatisUtil.closeSession(session);
        }
    }

    public static boolean checkDupItem(String custCode, String orderNum, String lineNum) {
        try {
            session = MyBatisUtil.openSession();

            Map<String, String> params = new HashMap<>();
            params.put("custCode", custCode);
            params.put("orderNum", orderNum);
            params.put("lineNum", lineNum);

            return session.getMapper(OrderItemMapper.class).getItemByOrderNumAndLineNum(params) == null;
        } finally {
            MyBatisUtil.closeSession(session);
        }
    }

    public static void updateOrderStatus2DB(String custCode, List<String> orders, String status) {
        try {
            session = MyBatisUtil.openSession();

            Map<String, String> params = new HashMap<>();
            for (String orderNum : orders) {
                params.clear();
                params.put("custCode", custCode);
                params.put("orderNum", orderNum);
                params.put("updated", status);
                params.put("orderStatus", "30");

                session.getMapper(SalesOrderMapper.class).updateOrder(params);
            }

            session.commit();
        } catch (Exception ex) {
            session.rollback();
            log.error("Error in changing order status to DB.");
        } finally {
            MyBatisUtil.closeSession(session);
        }
    }

    public static void updateOrderStatus2DB(String custCode, String orderNum, String status) {
        try {
            session = MyBatisUtil.openSession();

            Map<String, String> params = new HashMap<>();
            params.clear();
            params.put("custCode", custCode);
            params.put("orderNum", orderNum);
            params.put("updated", status);
            params.put("orderStatus", "30");

            session.getMapper(SalesOrderMapper.class).updateOrder(params);

            session.commit();
        } catch (Exception ex) {
            session.rollback();
            log.error("Error in changing order status to DB: " + ex.getMessage());
        } finally {
            MyBatisUtil.closeSession(session);
        }
    }

    // used for synchronize orders with SAP
    public static void updateOrderStatus2DB(List<SalesOrder> orders, String sync) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("Listed orders are synchronised: \n");

            session = MyBatisUtil.openSession();

            Map<String, String> params = new HashMap<>();
            for (SalesOrder order : orders) {
                params.put("custCode", order.getCompanyId());
                params.put("orderNum", order.getOrderNum());
                params.put("updated", sync);
                params.put("orderStatus", order.getOrderStatus());

                session.getMapper(SalesOrderMapper.class).updateOrder(params);
                sb.append(order.getOrderNum()).append("\n");
            }

            session.commit();

            sb.append(orders.size()).append(" orders in total. ");
            EmailUtil.sendEmail("Scheduler API info", sb.toString());
        } catch (Exception ex) {
            session.rollback();
            log.error("Error in changing order status to DB: " + ex.getMessage());
        } finally {
            MyBatisUtil.closeSession(session);
        }
    }
}
