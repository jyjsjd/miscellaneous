/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.task;

import com.bshg.util.SapUtil;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 */
public class SynWithSapTask extends APITask {

    private static final long TIME_INTERVAL = 24 * 60 * 60 * 1000;

    public SynWithSapTask(int hourOfDay, int minute, int second) {
        super(hourOfDay, minute, second, TIME_INTERVAL);
    }

    @Override
    public void run() {
        String synDate = (new DateTime()).toString(DateTimeFormat.forPattern("yyyy-MM-dd"));
        SapUtil.synOrderWithSap(synDate);
    }
}
