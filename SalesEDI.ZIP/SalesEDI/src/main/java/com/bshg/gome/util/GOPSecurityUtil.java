package com.bshg.gome.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class GOPSecurityUtil {

    /**
     * 对字符串进行签名
     *
     * @param content 被签名的内容
     * @param key 密码（secretKey）
     * @return 签名内容（32位字符串）
     */
    public static String md5sign(String content) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(content.getBytes());
            byte[] byteDigest = md.digest();
            int i;
            StringBuilder buf = new StringBuilder("");
            for (int offset = 0; offset < byteDigest.length; offset++) {
                i = byteDigest[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(i));
            }
            // 32位加密
            return buf.toString();
            // 16位的加密
            // return buf.toString().substring(8, 24);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }
}
