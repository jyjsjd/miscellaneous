/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.task;

import com.bshg.sn.util.SNXmlCreator;
import com.bshg.task.APITask;

/**
 *
 * @author admjingya
 */
public class SnOrderQeuryTask extends APITask{
    private static final long TIME_INTERVAL = 24 * 60 * 60 * 1000;

    public SnOrderQeuryTask(int hourOfDay, int minute, int second) {
        super(hourOfDay, minute, second, TIME_INTERVAL);
    }

    @Override
    public void run() {
        SNXmlCreator.createOrderQueryXml("10");
        SNXmlCreator.createOrderQueryXml("20");
    }
}
