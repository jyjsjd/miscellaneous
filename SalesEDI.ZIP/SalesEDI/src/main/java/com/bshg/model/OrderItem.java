/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.model;

import java.util.Date;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author admjingya
 */
@ToString
@NoArgsConstructor
public class OrderItem {

    @Getter
    private Integer id;
    @Getter
    @Setter
    private String companyId;
    @Getter
    @Setter
    private String orderNum;
    @Getter
    @Setter
    private String lineNum;
    @Getter
    @Setter
    private String merCode;
    @Getter
    @Setter
    private Integer qtyOrdered;
    @Getter
    @Setter
    private Integer qtyConfirmed;
    @Getter
    @Setter
    private Date createdDate;
    @Getter
    @Setter
    private Date deliveryDate;
    
    public OrderItem(String companyId, String orderNum, String lineNum, String merCode, 
            Integer qtyOrdered, Integer qtyConfirmed, Date createdDate, Date deliveryDate) {
        this.companyId = companyId;
        this.orderNum = orderNum;
        this.lineNum = lineNum;
        this.merCode = merCode;
        this.qtyOrdered = qtyOrdered;
        this.qtyConfirmed = qtyConfirmed;
        this.createdDate = createdDate;
        this.deliveryDate = deliveryDate;
    }
}
