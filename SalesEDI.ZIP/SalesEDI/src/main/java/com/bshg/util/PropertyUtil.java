package com.bshg.util;

import java.io.IOException;
import java.util.Properties;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class PropertyUtil {
    
    private static final String CONFIG = "/config_test.properties";
    
    public static String getValueByKey(String key) {
        Properties props = new Properties();
        
        try {
            props.load(PropertyUtil.class.getResourceAsStream(CONFIG));
        } catch (IOException e) {
            log.error("No property found in config.properties!");
        }
        
        if (props.containsKey(key)) {
            String value = props.getProperty(key);
            return value;
        } else {
            log.error("No property " + key + " found in config.properties!");
            return "";
        }
    }
}
