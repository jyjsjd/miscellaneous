/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.util;

import com.bshg.util.PropertyUtil;

/**
 *
 * @author admjingya
 */
public class SNConfig {

    public static final String FORMAT = "xml";
    public static final String VERSION = "v1.2";
    
    public static String APP_KEY;
    public static String APP_SECRET;
    public static String APP_URL;
    public static String PROXY;
    public static int PROXY_PORT;
    
    static {
        APP_KEY = PropertyUtil.getValueByKey("SN_APP_KEY");
        APP_SECRET = PropertyUtil.getValueByKey("SN_APP_SECRET");
        APP_URL = PropertyUtil.getValueByKey("SN_APP_URL");
        PROXY = PropertyUtil.getValueByKey("Proxy1");
        PROXY_PORT = Integer.parseInt(PropertyUtil.getValueByKey("Proxy_Port"));
    }
}
