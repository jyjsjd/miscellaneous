/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.mapper;

import com.bshg.model.OrderItem;
import java.util.List;
import java.util.Map;

/**
 *
 * @author admjingya
 */
public interface OrderItemMapper {

    OrderItem getItemById(Map params);

    List<OrderItem> getItemsByOrderNum(String orderNum);

    OrderItem getItemByOrderNumAndLineNum(Map params);

    int insertItem(OrderItem item);

    void insertItems(Map items);

//    int updateItem(Map params);
}
