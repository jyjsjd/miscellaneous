/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.test;

/**
 *
 * @author admjingya
 */
public class TestSNPo {

//    @Test
//    public void testPo() {
//        PurchaseOrderQueryRequest request = new PurchaseOrderQueryRequest();
//        request.setStartDate("2016-04-01");
//        request.setEndDate("2016-04-14");
//        request.setOrderType("NB");
//        request.setOrderStatus("10");
//        request.setPageNo(1);
////api入参校验逻辑开关，当测试稳定之后建议设置为 false 或者删除该行
//        request.setCheckParam(true);
//        DefaultSuningClient client = new DefaultSuningClient(SNConfig.APP_URL, SNConfig.APP_KEY, SNConfig.APP_SECRET, SNConfig.FORMAT,
//                5000, 5000, SNConfig.PROXY, SNConfig.PROXY_PORT);
//        try {
//            PurchaseOrderQueryResponse response = client.excute(request);
//            System.out.println("返回json/xml格式数据 :" + response.getBody());
//        } catch (SuningApiException e) {
//            e.printStackTrace();
//        }
//    }
}
