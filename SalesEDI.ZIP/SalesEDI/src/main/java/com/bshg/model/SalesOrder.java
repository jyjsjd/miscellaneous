/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.model;

import java.util.Date;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author admjingya
 */
@ToString
@NoArgsConstructor
public class SalesOrder {

    @Getter
    private Integer id;
    @Getter
    @Setter
    private String companyId;
    @Getter
    @Setter
    private String orderNum;
    @Getter
    @Setter
    private String orderStatus;
    @Getter
    @Setter
    private String updated;
    @Getter
    @Setter
    private Date createdDate;
    @Getter
    @Setter
    private String synDate;
    @Getter
    @Setter
    private String orderType;

    public SalesOrder(String companyId, String orderNum, String orderStatus, String updated, Date createdDate, String synDate, String orderType) {
        this.companyId = companyId;
        this.orderNum = orderNum;
        this.orderStatus = orderStatus;
        this.updated = updated;
        this.createdDate = createdDate;
        this.synDate = synDate;
        this.orderType = orderType;
    }
}
