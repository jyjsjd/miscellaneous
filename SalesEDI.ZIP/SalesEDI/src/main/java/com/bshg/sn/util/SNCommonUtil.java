/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.util;

/**
 *
 * @author admjingya
 */
public class SNCommonUtil {

    public static String getMethodName(String fileName) {
        String temp = fileName.split("_")[1];
        String appMethod;
        
        switch (temp) {
            case "PO":
                appMethod = "suning.purchaseorder.query";
                break;
            case "CONFIRM":
                appMethod = "suning.purchaseorder.confirm";
                break;
            default:
                appMethod = null;
                break;
        }
        return appMethod;
    }
}
