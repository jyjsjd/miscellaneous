/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.util;

import com.bshg.util.BSHFileUtil;
import com.bshg.util.EmailUtil;
import com.suning.api.DefaultSuningClient;
import com.suning.api.SuningResponse.SnError;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryRequest;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryResponse;
import com.suning.api.exception.SuningApiException;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author admjingya
 */
@Slf4j
public class SNMainUtil {

    private static final DefaultSuningClient SN_CLIENT = new DefaultSuningClient(
            SNConfig.APP_URL, SNConfig.APP_KEY,
            SNConfig.APP_SECRET, SNConfig.FORMAT,
            5000, 5000,
            SNConfig.PROXY, SNConfig.PROXY_PORT);

    public static void processPO(String custCode, String method, String bizParams, String fileName, File file)
            throws UnsupportedEncodingException {
        Map<String, String> requestParams = SNPoUtil.getRequestParamsMap(bizParams);

        PurchaseOrderQueryResponse response = getPoResponse(requestParams.get("orderCode"), requestParams.get("startDate"),
                requestParams.get("endDate"), requestParams.get("orderType"),
                requestParams.get("orderStatus"), Integer.parseInt(requestParams.get("pageNo")));

        if (response != null) {
            SnError snerror = response.getSnerror();

            if (snerror != null) {
                if (snerror.getErrorCode().contains("no-result")) {
                    BSHFileUtil.moveSuccessFile(custCode, requestParams.get("orderStatus"), snerror.getErrorMsg(), fileName, response.getBody(), file);
                    EmailUtil.sendEmail("Scheduler API info",
                            "No " + requestParams.get("orderStatus") + " order comes from Suning today!");
                } else {
                    EmailUtil.sendEmail("Scheduler API error", snerror.getErrorMsg());
                    BSHFileUtil.moveErrorFile(snerror.getErrorCode(), null, fileName, method, file);
                    log.error("Suning error: " + snerror.getErrorMsg());
                }
            } else {
                int pageNo = response.getSnhead().getPageNo();
                int pageTotal = response.getSnhead().getPageTotal();

                if ("10".equals(requestParams.get("orderStatus"))
                        || "20".equals(requestParams.get("orderStatus"))) {
                    SNPoUtil.saveOrdersAndItems(custCode, response);
                }

                BSHFileUtil.moveSuccessFile(custCode, requestParams.get("orderStatus"), "", fileName, response.getBody(), file);

                if (pageNo < pageTotal) {
                    requestParams.put("pageNo", String.valueOf(++pageNo));
                    SNXmlCreator.createOrderQueryXml(requestParams);
                }
            }
        }
    }

    private static PurchaseOrderQueryResponse getPoResponse(String orderCode, String startDate, String endDate,
            String orderType, String orderStatus, int pageNo) {
        PurchaseOrderQueryRequest request = new PurchaseOrderQueryRequest();

        if (orderCode != null && !"".equals(orderCode)) {
            request.setOrderCode(orderCode);
        }
        request.setStartDate(startDate);
        request.setEndDate(endDate);
        if (orderType != null && !"".equals(orderType)) {
            request.setOrderType(orderType);
        } else {
            request.setOrderType("NB");
        }
        request.setOrderStatus(orderStatus);
        if (pageNo == 0) {
            request.setPageNo(1);
        } else {
            request.setPageNo(pageNo);
        }
        request.setPageSize(50);

        //api入参校验逻辑开关，当测试稳定之后建议设置为 false 或者删除该行
//        request.setCheckParam(true);

        PurchaseOrderQueryResponse response = null;
        try {
            response = SN_CLIENT.excute(request);
        } catch (SuningApiException ex) {
            EmailUtil.sendEmail("Scheduler API error", "Error in getting suning response: " + ex.getErrMsg());
            log.error("Error in getting suning response: " + ex.getErrMsg());
        }

        return response;
    }
}
