/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.util;

import com.bshg.util.BSHFileUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 */
@Slf4j
public class SNXmlCreator {

    // This is for daily job
    public static void createOrderQueryXml(String orderStatus) {
        List<String> orderTypes = new ArrayList<>();
        orderTypes.add("NB");
        orderTypes.add("ZNB1");
        orderTypes.add("ZNB2");
        
        for (String orderType : orderTypes) {
            String startDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());
            String endDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());

            Document orderQuery = DocumentHelper.createDocument();

            Element root = orderQuery.addElement("sn_request");
            Element method = root.addElement("sn_body").addElement("purchaseOrder");
            method.addElement("startDate").addText(startDate);
            method.addElement("endDate").addText(endDate);
            method.addElement("orderType").addText(orderType);
            method.addElement("orderStatus").addText(orderStatus);
            method.addElement("pageNo").addText("1");
            method.addElement("pageSize").addText("50");

            BSHFileUtil.writeXml(orderQuery, "SN", "PO");
        }
    }

    // This is for orders more than 1 page.
    public static void createOrderQueryXml(Map<String, String> params) {
        Document orderQuery = DocumentHelper.createDocument();

        Element root = orderQuery.addElement("request");
        Element method = root.addElement("sn_body").addElement("purchaseOrder");
        method.addElement("startDate").addText(params.get("startDate"));
        method.addElement("endDate").addText(params.get("endDate"));
//        method.addElement("orderType").addText(params.get("orderType"));
//        method.addElement("orderStatus").addText(params.get("orderStatus"));
        method.addElement("pageNo").addText(params.get("pageNo"));
        method.addElement("pageSize").addText("50");

        BSHFileUtil.writeXml(orderQuery, "SN", "PO");
    }
}
