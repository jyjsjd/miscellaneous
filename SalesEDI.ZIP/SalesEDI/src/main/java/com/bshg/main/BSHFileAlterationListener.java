package com.bshg.main;

/**
 * Request folder listener: if a file is thrown to this folder, we will catch it
 * and send it to Gome.
 *
 * @author admJingYa
 */
import com.bshg.gome.task.GomeCounterTask;
import com.bshg.gome.task.GomeOrderConfirmTask;
import com.bshg.gome.task.GomeOrderQueryTask;
import com.bshg.gome.task.GomeRetailTask;
import com.bshg.gome.task.GomeStockTask;
import com.bshg.gome.util.GOPApiUtil;
import com.bshg.gome.util.GomeCommonUtil;
import com.bshg.gome.util.GomeMainUtil;
import com.bshg.sn.task.SnOrderQeuryTask;
import com.bshg.sn.util.SNCommonUtil;
import com.bshg.sn.util.SNMainUtil;
import com.bshg.task.SynWithSapTask;
import com.bshg.util.EmailUtil;
import com.bshg.util.PropertyUtil;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;

@Slf4j
public class BSHFileAlterationListener extends FileAlterationListenerAdaptor {

    private static final File REQUEST_ERROR = new File(PropertyUtil.getValueByKey("Request_Error"));
    private static final int TIME_TO_CREATE_ORDER = Integer.parseInt(PropertyUtil.getValueByKey("TIME_TO_CREATE_ORDER"));
    private static final int TIME_TO_CONFIRM_ORDER = Integer.parseInt(PropertyUtil.getValueByKey("TIME_TO_CONFIRM_ORDER"));

//    private AccessToken token = null;
    private GomeCounterTask counter = null;

    public BSHFileAlterationListener() {
        super();
        counter = GomeCounterTask.getInstence();
    }

    @Override
    public void onStart(FileAlterationObserver observer) {
        File directory = observer.getDirectory();

        for (File file : directory.listFiles()) {
            if (file.isFile()) {
                sendRequest(file);
            }
        }
    }

    @Override
    public void onFileCreate(File file) {
        sendRequest(file);
    }

    private void sendRequest(File file) {
        String fileName = file.getName();
        String accessTokenString = "c7c9ee273e4f338cbca4f3c0775315a6";

        if (fileName.startsWith("GOME")) {
//            fetchAccessToken();
//            accessTokenString = token.getAccessToken();

            /*if (token != null)*/ {
                // substract 1 from query limit 300
//                counter.sendOneRequest();

                if (counter.getCount() > 0) {
                    try {
                        String bizParam = FileUtils.readFileToString(file, Charsets.UTF_8);
                        String method = GomeCommonUtil.getMethodName(fileName);
                        String custCode = file.getName().split("_")[0];

                        // Invoke API
                        String xml = GOPApiUtil.setParams(accessTokenString, method, bizParam);

                        switch (method) {
                            case "BU_ORDER_QUERY":
                                GomeMainUtil.processPo(custCode, xml, fileName, file);
                                break;
                            case "BU_ORDER_CONFIRM":
                                GomeMainUtil.processConfirm(xml, fileName, file);
                                break;
                            case "SALES_INFO":
                                GomeMainUtil.processRetailAndStock(method, xml, fileName, file);
                                break;
                            case "STORE_INFO":
                                GomeMainUtil.processRetailAndStock(method, xml, fileName, file);
                                break;
                            default:
                                GomeMainUtil.processNonPo(method, xml, fileName, file);
                        }
                    } catch (UnsupportedEncodingException e) {
                        log.error("Unsupported encoding, filename: " + fileName);
                    } catch (IOException e) {
                        log.error("Error in reading file to string: file name: " + fileName);
                    }
                } else {
                    try {
                        FileUtils.copyFileToDirectory(file, REQUEST_ERROR);
                        FileUtils.deleteQuietly(file);

                        EmailUtil.sendEmail("Scheduler API error",
                                "We can't send more than 300 requests to Gome per day.");
                    } catch (IOException ex) {
                        log.error("Error in moving file: file name: " + fileName + ". " + ex.getMessage());
                    }
                }
            }
        } else if (fileName.startsWith("SN")) {
            try {
                String bizParam = FileUtils.readFileToString(file, Charsets.UTF_8);
                String method = SNCommonUtil.getMethodName(fileName);
                String custCode = file.getName().split("_")[0];

                switch (method) {
                    case "suning.purchaseorder.query":
                        SNMainUtil.processPO(custCode, method, bizParam, fileName, file);
                        break;
                    default:
                        ;
                }
            } catch (IOException ex) {
                log.error("Error in reading file to string: file name: " + fileName);
            }
        }
    }

//    private String fetchAccessToken() {
//        token = AccessToken.getInstance();
//        while (token == null
//                || "".equals(token.getAccessToken())
//                || token.getStatus() != 0) {
//            fetchAccessToken();
//
//            if (token != null && !"".equals(token.getAccessToken())) {
//                break;
//            }
//        }
//        return token.getAccessToken();
//    }

    public static void main(String[] args) {
        File monitorDir = new File(PropertyUtil.getValueByKey("Request_Folder"));
        FileAlterationMonitor monitor = new FileAlterationMonitor(5000);
        FileAlterationObserver observer = new FileAlterationObserver(monitorDir);
        BSHFileAlterationListener listener = new BSHFileAlterationListener();

        observer.addListener(listener);
        monitor.addObserver(observer);

        try {
            monitor.start();
            log.info("****************Scheduler started****************");
        } catch (Exception e) {
            log.error(("****************Scheduler does not start properly!****************"));
            EmailUtil.sendEmail("Scheduler API error",
                    "Scheduler does not start properly: " + e.getMessage());
        }

        GomeOrderConfirmTask gomeOrderConfirmTask = new GomeOrderConfirmTask(TIME_TO_CONFIRM_ORDER, 0, 0);
        GomeOrderQueryTask gomeOrderQueryTask = new GomeOrderQueryTask(TIME_TO_CREATE_ORDER, 30, 0);
        GomeRetailTask gomeRetailTask = new GomeRetailTask(TIME_TO_CONFIRM_ORDER, 10, 0);
        GomeStockTask gomeStockTask = new GomeStockTask(TIME_TO_CONFIRM_ORDER, 10, 0);
        GomeRetailTask gomeRetailTask1 = new GomeRetailTask(TIME_TO_CONFIRM_ORDER, 20, 0);
        GomeStockTask gomeStockTask1 = new GomeStockTask(TIME_TO_CONFIRM_ORDER, 20, 0);
        SnOrderQeuryTask snOrderQeuryTask = new SnOrderQeuryTask(TIME_TO_CREATE_ORDER, 30, 0);
        SynWithSapTask sapTask = new SynWithSapTask(23, 30, 0);
    }
}
