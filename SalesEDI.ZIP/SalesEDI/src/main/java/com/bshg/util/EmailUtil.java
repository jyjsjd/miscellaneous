package com.bshg.util;

import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author admjingya
 */
@Slf4j
public class EmailUtil {

    private static final String SMTP_SERVER = PropertyUtil.getValueByKey("SMTP_Server");
    private static final String EMAIL_ADDR = PropertyUtil.getValueByKey("Email_Address");

    public static void sendEmail(String subject, String message) {
        HtmlEmail email = new HtmlEmail();

        try {
            email.setHostName(SMTP_SERVER);
            email.addTo(EMAIL_ADDR);
            email.setFrom(EMAIL_ADDR);
            email.setCharset("UTF-8");
            email.setSubject(subject);
            
            if (subject.contains("error")) {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-Priority", "1");
                email.setHeaders(headers);
            }
            
            email.setMsg(message);
            email.send();
        } catch (EmailException ex) {
            log.error("Error in sending emails");
        }
    }
}
