package com.bshg.gome.task;

import com.bshg.task.APITask;
import com.bshg.util.PropertyUtil;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author admjingya
 */
@Slf4j
public class GomeCounterTask extends APITask {

    private static volatile GomeCounterTask counter = null;
    
    private static int count = Integer.parseInt(PropertyUtil.getValueByKey("Request_Limit"));
    private static final long TIME_INTERVAL = 24 * 60 * 60 * 1000;

    public static GomeCounterTask getInstence() {
        synchronized (GomeCounterTask.class) {
            if (counter == null) {
                counter = new GomeCounterTask(0, 0, 0);
            }
        }
        return counter;
    }

    public GomeCounterTask(int hourOfDay, int minute, int second) {
        super(hourOfDay, minute, second, TIME_INTERVAL);
    }

    @Override
    public void run() {
        GomeCounterTask.count = Integer.parseInt(PropertyUtil.getValueByKey("Request_Limit"));
    }

    public void sendOneRequest() {
        if (count > 0) {
            count--;
        } else {
            log.error("************Scheduler can't send any request, we have sent more than 300 times today!************");
        }
    }

    public int getCount() {
        if (counter != null) {
            return GomeCounterTask.count;
        } else {
            return 0;
        }
    }
}
