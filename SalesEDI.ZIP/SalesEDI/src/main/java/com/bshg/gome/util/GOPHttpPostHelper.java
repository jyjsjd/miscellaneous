package com.bshg.gome.util;

import com.bshg.proxy.JCIFSNTLMSchemeFactory;
import com.bshg.util.PropertyUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.Charsets;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.impl.auth.BasicSchemeFactory;
import org.apache.http.impl.auth.DigestSchemeFactory;
import org.apache.http.impl.auth.KerberosSchemeFactory;
import org.apache.http.impl.auth.SPNegoSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class GOPHttpPostHelper {

    public static String invokeApi(String appProtocol, String appUrl, int appPort, String appEnv, String appUriApi,
            Map<String, String> params) throws IOException {
        String returnStr = null;
        HttpHost target = null;
        HttpHost proxy = null;
        HttpPost httpPost = null;
        CloseableHttpResponse response = null;
        RequestConfig config = null;

        CloseableHttpClient httpClient = (CloseableHttpClient) getHttpClient();
        HttpClientContext context = HttpClientContext.create();
        context.setCredentialsProvider(getCredsProvider());
        target = new HttpHost(appUrl, appPort, appProtocol);

        proxy = new HttpHost(PropertyUtil.getValueByKey("Proxy1"), Integer.parseInt(PropertyUtil.getValueByKey("Proxy_Port")));
        config = RequestConfig.custom().setProxy(proxy).build();
        httpPost = new HttpPost(appEnv + appUriApi);
        httpPost.setEntity(new UrlEncodedFormEntity(getParams(params), Charsets.UTF_8));
        httpPost.setConfig(config);

        try {
            response = httpClient.execute(target, httpPost, context);
            returnStr = EntityUtils.toString(response.getEntity());
        } finally {
            response.close();
            httpClient.close();
        }
        return returnStr;
    }

    private static HttpClient getHttpClient() {
        Registry<AuthSchemeProvider> authSchemeRegistry = RegistryBuilder.<AuthSchemeProvider>create()
                .register(AuthSchemes.NTLM, new JCIFSNTLMSchemeFactory())
                .register(AuthSchemes.BASIC, new BasicSchemeFactory())
                .register(AuthSchemes.DIGEST, new DigestSchemeFactory())
                .register(AuthSchemes.SPNEGO, new SPNegoSchemeFactory())
                .register(AuthSchemes.KERBEROS, new KerberosSchemeFactory()).build();

        return HttpClients.custom().setDefaultAuthSchemeRegistry(authSchemeRegistry).build();
    }

    private static CredentialsProvider getCredsProvider() {
        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope(PropertyUtil.getValueByKey("Proxy1"),
                        Integer.parseInt(PropertyUtil.getValueByKey("Proxy_Port"))),
                new NTCredentials(PropertyUtil.getValueByKey("NT_UserName"), PropertyUtil.getValueByKey("NT_Password"),
                        PropertyUtil.getValueByKey("NT_WorkStation"), PropertyUtil.getValueByKey("NT_Domain")));
        return credsProvider;
    }

    private static List<NameValuePair> getParams(Map<String, String> params) {
        List<NameValuePair> nvps = new ArrayList<>();
        if (params != null && !params.isEmpty()) {
            Iterator<String> it = params.keySet().iterator();
            while (it.hasNext()) {
                String key = it.next();
                nvps.add(new BasicNameValuePair(key, params.get(key)));
            }
        }
        return nvps;
    }
}
