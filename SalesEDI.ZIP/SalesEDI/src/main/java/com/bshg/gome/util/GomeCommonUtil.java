package com.bshg.gome.util;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

@Slf4j
public class GomeCommonUtil {

    public static Map<String, String> getStatusParams(String xml) {
        Map<String, String> params = new HashMap<>();

        SAXReader reader = new SAXReader();
        Document doc = null;
        try {
            doc = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            Element root = doc.getRootElement();

            for (Iterator i = root.elementIterator(); i.hasNext();) {
                Element element = (Element) i.next();

                if ("status".equals(element.getQualifiedName())) {
                    params.put("status", element.getStringValue());
                }
                if ("message".equals(element.getQualifiedName())) {
                    params.put("message", element.getStringValue());
                }

                if ("0".equals(params.get("status"))) {
                    if ("data".equals(element.getQualifiedName())) {
                        Element result = element.element("STORE_INFO_RESULT");
                        if (result == null) {
                            result = element.element("SALES_INFO_RESULT");
                        }

                        if (result != null) {
                            for (Iterator j = result.elementIterator(); j.hasNext();) {
                                Element jElement = (Element) j.next();
                                if ("FILE_CODE".equals(jElement.getQualifiedName())) {
                                    params.put("data", element.getStringValue());
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } catch (UnsupportedEncodingException | DocumentException e) {
            log.error("Error to get XML parameters");
        }

        return params;
    }

    public static String getMethodName(String fileName) {
        String temp = fileName.split("_")[1];
        String methodName = null;

        switch (temp) {
            case "PO":
                methodName = "BU_ORDER_QUERY";
                break;
            case "RETAIL":
                methodName = "SALES_INFO";
                break;
            case "STOCK":
                methodName = "STORE_INFO";
                break;
            case "BILL":
                methodName = "BILL_JX_QUERY";
                break;
            case "VOUCHER":
                methodName = "INVOICE_VOUCHER_QUERY";
                break;
            case "CONFIRM":
                methodName = "BU_ORDER_CONFIRM";
                break;
            default:
                methodName = null;
                break;
        }
        return methodName;
    }

    /**
     * 0，处理成功 1010, "AccessToken无效" 1011, "AppKey无效" 1012, "Api版本错误" 1013,
     * "未找到指定的业务方法，method参数错误" 1014, "要求返回的数据格式错误，只允许XML或JSON" 1015, "参数签名错误"
     * 1016, "请求时间错误" 1017, "请求IP错误" 1020, "用户访问次数超过限制" 2001, "业务参数格式错误"
     *
     * @param statusCode
     * @return statusDetail
     */
    public static String getStatusDetail(String statusCode) {
        String statusDetail = null;

        switch (statusCode) {
            case "0":
                statusDetail = "0, Success";
                break;
            case "1010":
                statusDetail = "1010, Invalid AccessToken";
                break;
            case "1011":
                statusDetail = "1011, Invalid AppKey";
                break;
            case "1012":
                statusDetail = "1012, Invalid API version";
                break;
            case "1013":
                statusDetail = "1013, Invalid method";
                break;
            case "1014":
                statusDetail = "1014, Invalid return file format";
                break;
            case "1015":
                statusDetail = "1015, Invalid sign";
                break;
            case "1016":
                statusDetail = "1016, Invalid request time";
                break;
            case "1017":
                statusDetail = "1017, Invalid IP address";
                break;
            case "1020":
                statusDetail = "1020, Too many request";
                break;
            case "2001":
                statusDetail = "2001, Invalid parameter format";
                break;
            default:
                statusDetail = "Unknown error";
                break;
        }
        return statusDetail;
    }
}
