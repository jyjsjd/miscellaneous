/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.test;

/**
 *
 * @author admjingya
 */
public class TestXml {

//    @Test
//    public void testCreateOrderConfirm() {
//        SqlSession session = MyBatisUtil.openSession();
//        Map<String, List<OrderItem>> orderItemMap = new HashMap<>();
//
//        String orderNum = "4000029237";
//        List<OrderItem> items = session.getMapper(OrderItemMapper.class).getItemsByOrderNum(orderNum);
//
//        orderItemMap.put(orderNum, items);
//
//        XmlCreator.createOrderConfirmXml(orderItemMap);
//
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testCreateOrderInquiry() {
//        XmlCreator.createOrderQueryXml("10");
//    }
//    @Test
//    public void testStatusCode() throws IOException {
//        String xml = FileUtils.readFileToString(new File("E:\\jyTest\\result_error\\GOME_CONFIRM_1_20160510085857.xml"));
//        System.out.println(CommonUtil.getStatusCode(xml));
//    }
//    @Test
//    public void testOrderNum() throws IOException {
//        String xml = FileUtils.readFileToString(new File("E:\\jyTest\\result_success\\GOME_CONFIRM_20160511140599_20160511141907.xml"));
//        OrderUtil.updateOrderStatus(xml);
//    }
//    @Test
//    public void testSalesInfo() {
//        XmlCreator.createRetailInfo();
//    }
//    @Test
//    public void testSNorderquerydaily(){
//        SNXmlCreator.createOrderQueryXml("10");
//    }
//    @Test
//    public void testDaily() {
//        GomeXmlCreator.createOrderQueryXml("10");
//    }
}
