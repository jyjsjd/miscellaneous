/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 */
@Slf4j
public class BSHFileUtil {

    private static final File REQUEST_SUCCESS = new File(PropertyUtil.getValueByKey("Request_Success"));
    private static final File REQUEST_ERROR = new File(PropertyUtil.getValueByKey("Request_Error"));
    private static final String REQUEST_FOLDER = PropertyUtil.getValueByKey("Request_Folder");

    // this works for Gome PO
    public static void moveSuccessFile(String custCode, String orderStatus, String resultStatus, int pageCount,
            String fileName, String content, File successFile) {
        try {
            FileUtils.copyFileToDirectory(successFile, REQUEST_SUCCESS);
            FileUtils.deleteQuietly(successFile);
            
            if (!("10".equals(orderStatus)) // abandon the return xml if order status is "10"
                    && pageCount != 0) {    // abandon the xml if page count is 0
                FileUtils.writeStringToFile(new File(buildResponseFileName(custCode, fileName, "", true)), content, Charsets.UTF_8);
            }

            if (pageCount == 0) {
                EmailUtil.sendEmail("Scheduler API info",
                        "No " + resultStatus + " order comes back from Gome.");
            }

            log.info("Response file saved: " + buildResponseFileName(custCode, fileName, "", true));
        } catch (IOException ex) {
            log.error("Error happens when moving po success request files: " + ex.getMessage());
        }
    }

    // this works for Gome non-PO
    public static void moveSuccessFile(String method, String fileName, String content, File successFile) {
        try {
            FileUtils.copyFileToDirectory(successFile, REQUEST_SUCCESS);
            FileUtils.deleteQuietly(successFile);
            
            if (!("SALES_INFO".equals(method) || "STORE_INFO".equals(method))) {
                FileUtils.writeStringToFile(new File(buildResponseFileName("GOME", fileName, method, true)), content, Charsets.UTF_8);
            }

            log.info("Response file saved: " + buildResponseFileName("GOME", fileName, method, true));
        } catch (IOException ex) {
            log.error("Error happens when moving non-po success request files.");
        }
    }

    // this works for SN PO
    public static void moveSuccessFile(String custCode, String orderStatus, String errorCode, String fileName, String content, File successFile) {
        try {
            FileUtils.copyFileToDirectory(successFile, REQUEST_SUCCESS);
            FileUtils.deleteQuietly(successFile);
            
            if ((errorCode != null && !errorCode.contains("no-result"))) {    // abandon the xml if no-result
                FileUtils.writeStringToFile(new File(buildResponseFileName(custCode, fileName, "", true)), content, Charsets.UTF_8);
            }

            if (errorCode != null && errorCode.contains("no-result")) {
                EmailUtil.sendEmail("Scheduler API info",
                        "No " + orderStatus + " order comes back from Suning.");
            }

            log.info("Response file saved: " + buildResponseFileName(custCode, fileName, "", true));
        } catch (IOException ex) {
            log.error("Error happens when moving po success request files: " + ex.getMessage());
        }
    }

    public static void moveErrorFile(String statusCode, String message, String fileName, String content, File errorFile) {
        try {
            FileUtils.copyFileToDirectory(errorFile, REQUEST_ERROR);
            FileUtils.deleteQuietly(errorFile);
            
            FileUtils.writeStringToFile(new File(buildResponseFileName(null, fileName, "", false)), content, Charsets.UTF_8);
            log.error("Status code error: request file name " + errorFile.getName()
                    + ". Response status code: " + statusCode);
            EmailUtil.sendEmail("Scheduler API error",
                    "Status code error: file name " + errorFile.getName()
                    + ". Response status code: " + statusCode + " " + message);
        } catch (IOException ex) {
            log.error("Error happens when moving error request files.");
        }
    }

    public static String buildResponseFileName(String custCode, String fileName, String method, boolean success) {
        String returnFileName = null;
        StringBuilder fileNameBuilder = new StringBuilder();
        fileNameBuilder.append(fileName.split("\\.")[0]).append("_")
                .append(DateTimeFormat.forPattern("yyyyMMddHHMMSS").print(new DateTime()))
                .append(".xml");

        if (success) {
            if ("".equals(method)) {
                if ("GOME".equals(custCode)) {
                    returnFileName = fileNameBuilder.insert(0, PropertyUtil.getValueByKey("GOME_Response_Success")).toString();
                } else if ("SN".equals(custCode)) {
                    returnFileName = fileNameBuilder.insert(0, PropertyUtil.getValueByKey("SN_Response_Success")).toString();
                }
            } else { // This is only for retail and stock
                String[] nameSplit = fileName.split("\\.")[0].split("_");
                StringBuilder fileNameSb = new StringBuilder();
                fileNameSb.append(PropertyUtil.getValueByKey("Retail_Stock_Folder"))
                        .append(nameSplit[0]).append("_")
                        .append(nameSplit[1]).append("_")
                        .append(DateTimeFormat.forPattern("yyyyMMdd")
                                .print(new DateTime()))
                        .append(".txt");

                returnFileName = fileNameSb.toString();
            }
        } else {
            returnFileName = fileNameBuilder.insert(0, PropertyUtil.getValueByKey("Response_Error")).toString();
        }
        return returnFileName;
    }

    public static void writeXml(Document document, String custCode, String xmlType) {
        String fileName = fileNameGenerator(custCode, xmlType);

        OutputFormat format = OutputFormat.createPrettyPrint();
        format.setSuppressDeclaration(true);

        XMLWriter writer;
        try {
            writer = new XMLWriter(new FileWriter(fileName), format);
            writer.write(document);
            writer.close();
        } catch (IOException ex) {
            EmailUtil.sendEmail("Scheduler API error", ex.getMessage());
            log.error("Error in saving query XML files.");
        }
    }

    public static String fileNameGenerator(String custCode, String xmlType) {
        Random random = new Random();
        StringBuilder fileName = new StringBuilder();
        
        fileName.append(REQUEST_FOLDER).append("\\").append(custCode).append("_")
                .append(xmlType).append("_")
                .append(DateTimeFormat.forPattern("yyyyMMddHHMMSS").print(new DateTime()))
                .append(random.nextInt(100000))
                .append(".xml");

        return fileName.toString();
    }
}
