package com.bshg.gome.util;

import com.bshg.util.EmailUtil;
import com.bshg.util.PropertyUtil;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import sun.misc.BASE64Encoder;

@Slf4j
public class GOPApiUtil {

    public static String setParams(String accessToken, String bizMethod, String bizParam)
            throws UnsupportedEncodingException {
        String responseStr = null;
        String format = PropertyUtil.getValueByKey("File_Format");
        String reqTime = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
        Map<String, String> params = new HashMap<>();

        params.put("version", GOPConfig.APP_VERSION);
        params.put("req_time", reqTime);
        params.put("access_token", accessToken);
        params.put("format", format);
        params.put("biz_method", bizMethod);
        params.put("biz_param", bizParam);
        params.put("app_key", GOPConfig.APP_KEY);
        params.put("sign", getSign(format, accessToken, reqTime, GOPConfig.APP_VERSION, bizMethod, bizParam));

        try {
            responseStr = GOPHttpPostHelper.invokeApi(GOPConfig.APP_PROTOCOL, GOPConfig.APP_URL, GOPConfig.APP_PORT,
                    GOPConfig.APP_ENV, GOPConfig.APP_URI_API, params);
        } catch (IOException e) {
            log.error("Error in invoking GOME API.");
            EmailUtil.sendEmail("Scheduler API error", 
                    "Error in invoking GOME API. " + e.getMessage());
        }

        return responseStr;
    }

    private static String getSign(String format, String accessToken, String reqTime, String appVersion,
            String bizMethod, String bizParam) throws UnsupportedEncodingException {
        StringBuilder content = new StringBuilder();
        content.append(accessToken);
        content.append("|").append(format);
        content.append("|").append(appVersion);
        content.append("|").append(reqTime);
        content.append("|").append(bizMethod);
        // Base64加密后的字符串中，要把换行符号去掉！
        content.append("|").append(new BASE64Encoder().encode(bizParam.getBytes("UTF-8")).replaceAll("[\r\n]", ""));
        content.append("|").append(GOPConfig.APP_SECRET);

        return GOPSecurityUtil.md5sign(content.toString());
    }
}
