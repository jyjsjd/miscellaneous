/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.test;

//import com.bshg.gome.util.MyBatisUtil;
//import com.bshg.gome.mapper.SalesOrderMapper;
//import com.bshg.gome.model.OrderItem;
//import com.bshg.gome.model.SalesOrder;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import org.apache.ibatis.session.SqlSession;
//import org.junit.Test;
/**
 *
 * @author admjingya
 */
public class TestBatis {

//    @Test
//    public void testInsertItem() {
//        SqlSession session = MyBatisUtil.openSession();
//        OrderItem item = new OrderItem("GOME", "1111", "EERW4", "gggDD", 112, 122, new Date());
//        session.getMapper(OrderItemMapper.class).insertItem(item);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testSelectItem() {
//        SqlSession session = MyBatisUtil.openSession();
//        OrderItem item = session.getMapper(OrderItemMapper.class).getItemById(99);
//        System.out.println(item.toString());
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testSelectItems() {
//        SqlSession session = MyBatisUtil.openSession();
//        List<OrderItem> items = session.getMapper(OrderItemMapper.class).getItemsByOrderNum("4000029381");
//        for (Iterator<OrderItem> iterator = items.iterator(); iterator.hasNext();) {
//            OrderItem next = iterator.next();
//            System.out.println(next);
//        }
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//    
//    @Test
//    public void testUpdateItem() {
//        SqlSession session = MyBatisUtil.openSession();
//        OrderItem item = session.getMapper(OrderItemMapper.class).getItemById(1);
//        Map<String, String> params = new HashMap(); 
//        params.put("updated", "55"); 
//        params.put("orderNum", "1111");
//        session.getMapper(OrderItemMapper.class).updateItem(params);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testInsertItems() {
//        SqlSession session = MyBatisUtil.openSession();
//        List<OrderItem> items = new ArrayList<>();
//        Map map = new HashMap();
//
//        OrderItem item1 = new OrderItem("gome", "222222", "123", "123", 2, 2, new Date());
//        OrderItem item2 = new OrderItem("gome", "333333", "123", "123", 2, 2, new Date());
//
//        items.add(item1);
//        items.add(item2);
//
//        map.put("list", items);
//
//        session.getMapper(OrderItemMapper.class).insertItems(map);
//
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testInsertOrder() {
//        SqlSession session = MyBatisUtil.openSession();
//        SalesOrder order = new SalesOrder("GOME", "123", "0", new Date());
//        session.getMapper(SalesOrderMapper.class).insertOrder(order);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testInsertOrders() {
//        SqlSession session = MyBatisUtil.openSession();
//        List<SalesOrder> orders = new ArrayList<>();
//        Map params = new HashMap(); 
//        
//        SalesOrder order1 = new SalesOrder("GOME", "111", "0", new Date());
//        SalesOrder order2 = new SalesOrder("GOME", "222", "0", new Date());
//        
//        orders.add(order1); 
//        orders.add(order2); 
//        
//        params.put("list", orders); 
//        
//        session.getMapper(SalesOrderMapper.class).insertOrders(params);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//    
//    @Test
//    public void testGetOrderByNum() {
//        SqlSession session = MyBatisUtil.openSession();
//        String orderNum = "123";
//        SalesOrder order = session.getMapper(SalesOrderMapper.class).getOrderByNum(orderNum);
//        System.out.println(order);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//
//    @Test
//    public void testUpdateOrder() {
//        SqlSession session = MyBatisUtil.openSession();
//        SalesOrder order = session.getMapper(SalesOrderMapper.class).getOrderByNum("123");
//        Map<String, String> params = new HashMap(); 
//        params.put("updated", "66"); 
//        params.put("orderNum", "4000029191");
//        session.getMapper(SalesOrderMapper.class).updateOrder(params);
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
//    @Test
//    public void testGetOrderByDate() {
//        SqlSession session = MyBatisUtil.openSession();
//        Date today = new Date(); 
//        List<SalesOrder> orders = session.getMapper(SalesOrderMapper.class).getOrdersByDate(today);
//        System.out.println(today.toString());
//        for (SalesOrder order : orders) {
//            System.out.println(order.getOrderNum());
//        }
//        session.commit();
//        MyBatisUtil.closeSession(session);
//    }
}
