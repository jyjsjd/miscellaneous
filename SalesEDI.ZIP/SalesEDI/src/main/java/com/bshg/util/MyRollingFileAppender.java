/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.util;

import org.apache.log4j.Priority;
import org.apache.log4j.RollingFileAppender;

/**
 *
 * @author admjingya
 */
public class MyRollingFileAppender extends RollingFileAppender {

    @Override
    public boolean isAsSevereAsThreshold(Priority priority) {
        return this.getThreshold().equals(priority);
    }
}
