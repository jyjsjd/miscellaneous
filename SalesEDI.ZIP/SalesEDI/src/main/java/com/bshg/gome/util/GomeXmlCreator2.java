/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.gome.util;

import com.bshg.util.PropertyUtil;
import java.io.FileWriter;
import java.io.IOException;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 * only works for retail and stock
 */
public class GomeXmlCreator2 {

    private static final String REQUEST_FOLDER = PropertyUtil.getValueByKey("Retail_Stock_Folder");

    public static void createRetailInfo() {
        String createDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());
        String createMonth = DateTimeFormat.forPattern("yyyy-MM").print(new DateTime());

        Document salesInfo = DocumentHelper.createDocument();

        Element root = salesInfo.addElement("request");
        Element method = root.addElement("SALES_INFO_PARAM");
        method.addElement("CREATE_DATE").addText(createDate);
        method.addElement("CREATE_MONTH").addText(createMonth);

        writeXml(salesInfo, "RETAIL");
    }

    public static void createStockInfo() {
        String createDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());

        Document salesInfo = DocumentHelper.createDocument();

        Element root = salesInfo.addElement("request");
        Element method = root.addElement("STORE_INFO_PARAM");
        method.addElement("CREATE_DATE").addText(createDate);

        writeXml(salesInfo, "STOCK");
    }

    private static void writeXml(Document document, String xmlType) {
        String fileName = fileNameGenerator(xmlType);

        OutputFormat format = OutputFormat.createPrettyPrint();
        format.setSuppressDeclaration(true);

        XMLWriter writer;
        try {
            writer = new XMLWriter(new FileWriter(fileName), format);
            writer.write(document);
            writer.close();
        } catch (IOException ex) {
            //TODO
        }
    }

    private static String fileNameGenerator(String xmlType) {
        StringBuilder fileName = new StringBuilder();
        fileName.append(REQUEST_FOLDER).append("\\GOME_").append(xmlType).append("_")
                .append(DateTimeFormat.forPattern("yyyyMMdd").print(new DateTime()))
                .append(".xml");

        return fileName.toString();
    }
}
