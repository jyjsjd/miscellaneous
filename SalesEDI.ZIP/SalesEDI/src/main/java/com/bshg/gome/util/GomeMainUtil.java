/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.gome.util;

import com.bshg.model.OrderItem;
import com.bshg.util.BSHFileUtil;
import com.bshg.util.EmailUtil;
import com.bshg.util.PropertyUtil;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import lombok.extern.slf4j.Slf4j;
import sun.misc.BASE64Decoder;

/**
 *
 * @author admjingya
 */
@Slf4j
public class GomeMainUtil {

    public static void processPo(String custCode, String xml, String fileName, File file) {
        Map<String, String> params = GomePoUtil.getBizParamsMap(xml);
        String statusCode = params.get("status");
        String message = params.get("message");
        String orderStatus;
        String resultStatus;

        if ("0".equals(statusCode)) {
            resultStatus = params.get("RESULT_STATUS");
            orderStatus = params.get("ORDER_STATUS");
            int pageNo = Integer.parseInt(params.get("PAGE_NO"));
            int pageCount = Integer.parseInt(params.get("PAGE_COUNT"));

            // create order confirm xml
            createOrderConfirmXml(custCode, orderStatus, pageCount, xml);
            BSHFileUtil.moveSuccessFile(custCode, orderStatus, resultStatus, pageCount, fileName, xml, file);

            // create query file for multiple pages
            if (pageNo < pageCount) {
                if ("30".equals(orderStatus)) {
                    params.put("PAGE_NO", String.valueOf(++pageNo));
                }
                GomeXmlCreator.createOrderQueryXml(params);
            }
        } else {
            BSHFileUtil.moveErrorFile(statusCode, message, fileName, xml, file);
        }
    }

    public static void processNonPo(String method, String bizParams, String fileName, File file) {
        Map<String, String> params = GomeCommonUtil.getStatusParams(bizParams);
        String statusCode = params.get("status");
        String message = params.get("message");

        if ("0".equals(statusCode)) {
            BSHFileUtil.moveSuccessFile(method, fileName, bizParams, file);
        } else {
            BSHFileUtil.moveErrorFile(statusCode, message, fileName, bizParams, file);
        }
    }

    public static void processRetailAndStock(String method, String bizParams, String fileName, File file) throws IOException {
        Map<String, String> params = GomeCommonUtil.getStatusParams(bizParams);
        String statusCode = params.get("status");
        String message = params.get("message");
        String data = params.get("data").substring(12);

        if ("0".equals(statusCode) && !"".equals(data)) {
            ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(decodeBase64(data)));
            ZipEntry entry = zis.getNextEntry();

            File fout = new File(PropertyUtil.getValueByKey("Retail_Stock_Folder"), entry.getName());
            if (!fout.exists()) {
                (new File(fout.getParent())).mkdirs();
            }
            FileOutputStream out = new FileOutputStream(fout);
            BufferedOutputStream bos = new BufferedOutputStream(out);
            BufferedInputStream bis = new BufferedInputStream(zis);
            int b;
            while ((b = bis.read()) != -1) {
                bos.write(b);
            }
            bos.close();
            out.close();

            BSHFileUtil.moveSuccessFile(method, fileName, bizParams, file);
        } else if ("0".equals(statusCode)) {
            BSHFileUtil.moveSuccessFile(method, fileName, bizParams, file);
        } else {
            EmailUtil.sendEmail("Scheduler API error", "Error in query: \n" + bizParams);
            BSHFileUtil.moveErrorFile(statusCode, message, fileName, bizParams, file);
        }
    }

    public static void processConfirm(String xml, String fileName, File file) {
        Map<String, String> params = GomeCommonUtil.getStatusParams(xml);
        String statusCode = params.get("status");
        String message = params.get("message");

        if ("0".equals(statusCode)) {
            BSHFileUtil.moveSuccessFile("", fileName, xml, file);
            // update order status to "Confirmed"
            GomePoUtil.updateOrderStatus("GOME", xml, "Auto Confirm");
        } else {
            BSHFileUtil.moveErrorFile(statusCode, message, fileName, xml, file);
        }
    }

    private static void createOrderConfirmXml(String custCode, String orderStatus, int pageCount, String xml) {
        if ("10".equals(orderStatus)) {
            Map<String, List<OrderItem>> orderItems = GomePoUtil.saveOrdersAndItems(custCode, xml);

            if (!orderItems.isEmpty()) {
                GomeXmlCreator.createOrderConfirmXml(orderItems);
            } else {
                EmailUtil.sendEmail("Scheduler API info", "No order needs to be confirmed");
            }
        } else if (pageCount != 0) {
            GomePoUtil.saveOrdersAndItems(custCode, xml);
        }
    }

    public static byte[] decodeBase64(String data) {
        byte[] decode = null;
        try {
            decode = (new BASE64Decoder()).decodeBuffer(data);
        } catch (IOException ex) {
            log.error("Error in decode BASE64 for retail or stock: " + ex.getMessage());
        }
        return decode;
    }
}
