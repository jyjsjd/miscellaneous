/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.gome.util;

import com.bshg.model.OrderItem;
import com.bshg.model.SalesOrder;
import com.bshg.util.DBUtil;
import com.bshg.util.EmailUtil;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 * only for processing orders
 *
 * @author admjingya
 */
@Slf4j
public class GomePoUtil {

    /**
     * Get order status, return code
     *
     * @param bizParams
     * @return
     */
    public static Map<String, String> getBizParamsMap(String bizParams) {
        Map<String, String> params = new HashMap<>();
        SAXReader reader = new SAXReader();
        
        try {
            Document doc = reader.read(new ByteArrayInputStream(bizParams.getBytes("UTF-8")));
            Element root = doc.getRootElement();

            for (Iterator i = root.elementIterator(); i.hasNext();) {
                Element element = (Element) i.next();

                if ("status".equals(element.getQualifiedName())) {
                    params.put("status", element.getStringValue());
                }
                if ("message".equals(element.getQualifiedName())) {
                    params.put("message", element.getStringValue());
                }
            }

            Element orderQuery = doc.getRootElement().element("data").
                    element("BU_ORDER_QUERY_RESULT");
            if (orderQuery != null) {
                for (Iterator qIterator = orderQuery.elementIterator(); qIterator.hasNext();) {
                    Element next = (Element) qIterator.next();
                    switch (next.getQualifiedName()) {
                        case "PAGE_NO":
                            params.put("PAGE_NO", next.getStringValue());
                            break;
                        case "PAGE_COUNT":
                            params.put("PAGE_COUNT", next.getStringValue());
                            break;
                        case "START_TIME":
                            params.put("START_TIME", next.getStringValue());
                            break;
                        case "END_TIME":
                            params.put("END_TIME", next.getStringValue());
                            break;
                        case "ORDER_STATUS":
                            params.put("RESULT_STATUS", next.getStringValue());
                        default:
                            ;
                    }
                }

                Element ordersElement = orderQuery.element("ORDERS");
                if (ordersElement != null) {
                    for (Iterator oIterator = ordersElement.elementIterator("ORDER"); oIterator.hasNext();) {
                        Element orderElement = (Element) oIterator.next();
                        String orderStatus = orderElement.elementText("ORDER_STATUS");
                        params.put("ORDER_STATUS", orderStatus);
                        break;
                    }
                }
            }
        } catch (UnsupportedEncodingException | DocumentException e) {
            log.error("Error in parsing po response parameters");
        }

        return params;
    }

    public static Map<String, List<OrderItem>> saveOrdersAndItems(String custCode, String xml) {
        Map<String, List<OrderItem>> orderItemMap = new HashMap<>();
        List<SalesOrder> orders = new ArrayList<>();
        List<OrderItem> items = new ArrayList<>();
        SAXReader reader = new SAXReader();
        
        try {
            Document doc = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
            Element ordersElement = doc.getRootElement().element("data").
                    element("BU_ORDER_QUERY_RESULT").element("ORDERS");
            //ORDERS 
            for (Iterator oIterator = ordersElement.elementIterator("ORDER"); oIterator.hasNext();) {
                Element orderElement = (Element) oIterator.next();
                String orderNum = orderElement.elementText("ORDER_CODE");

                // check if order is existed
                if (DBUtil.checkDupOrder(custCode, orderNum)) {
                    String synDate = (new DateTime()).toString(DateTimeFormat.forPattern("yyyy-MM-dd"));
                    String orderStatus = orderElement.elementText("ORDER_STATUS");

                    if ("10".equals(orderStatus)) {
                        SalesOrder order = new SalesOrder(custCode, orderNum, orderStatus, null, new Date(), synDate, null);
                        orders.add(order);
                    } else if ("30".equals(orderStatus)) {
                        SalesOrder order = new SalesOrder(custCode, orderNum, orderStatus, "Manual Confirm", new Date(), synDate, null);
                        orders.add(order);
                    }

                }

                //ORDER_ITEMS
                List<OrderItem> orderItems = new ArrayList<>();
                for (Iterator iIterator = orderElement.elementIterator("ORDER_ITEMS"); iIterator.hasNext();) {
                    Element itemsElement = (Element) iIterator.next();
                    //ORDER_ITEM
                    for (Iterator item = itemsElement.elementIterator("ORDER_ITEM"); item.hasNext();) {
                        Element itemElement = (Element) item.next();

                        String lineNum = itemElement.elementText("ORDER_ITEM_CODE");
                        String merCode = itemElement.elementText("MER_ID");
                        int qtyOrdered = Integer.parseInt(itemElement.elementText("AMOUNT"));

                        if (DBUtil.checkDupItem(custCode, orderNum, lineNum)) {
                            OrderItem orderItem = new OrderItem(custCode, orderNum, lineNum,
                                    merCode, qtyOrdered, qtyOrdered, new Date(), new Date());
                            items.add(orderItem);
                            orderItems.add(orderItem);
                        }
                    }
                }

                if (!orderItems.isEmpty()) {
                    orderItemMap.put(orderNum, orderItems);
                }
            }
            DBUtil.saveOrdersAndItems2DB(orders, items);

        } catch (DocumentException | UnsupportedEncodingException e) {
            log.error("Error in saving orders and items to DB.");
            EmailUtil.sendEmail("Scheduler API error", e.getMessage());
        }
        return orderItemMap;
    }

    public static void updateOrderStatus(String custCode, String response, String status) {
        List<String> orders = new ArrayList<>();
        StringBuilder errMsg = new StringBuilder();
        SAXReader reader = new SAXReader();

        try {
            Document doc = reader.read(new ByteArrayInputStream(response.getBytes("UTF-8")));
            Element orderNums = doc.getRootElement().element("data");

            for (Iterator iterator = orderNums.elementIterator("BU_ORDER_CONFIRM_RESULT"); iterator.hasNext();) {
                Element orderElement = (Element) iterator.next();
                if (orderElement != null) {
                    if ("S".equals(orderElement.elementText("RESULT"))) {
                        orders.add(orderElement.elementText("ORDER_CODE"));
                    } else if ("F".equals(orderElement.elementText("RESULT"))) {
                        if (errMsg.length() == 0) {
                            errMsg.append("Order: ").append(orderElement.elementText("ORDER_CODE"))
                                    .append(" Reason: ").append(orderElement.elementText("ERROR_MSG"));
                        } else {
                            errMsg.append("\r\n").append("Order: ").append(orderElement.elementText("ORDER_CODE"))
                                    .append(" Reason: ").append(orderElement.elementText("ERROR_MSG"));
                        }
                    }
                }
            }

            // Save the updates to DB
            DBUtil.updateOrderStatus2DB(custCode, orders, status);

            // Send emails if error happens
            if (!("".equals(errMsg.toString()))) {
                EmailUtil.sendEmail("Scheduler API error",
                        "Order Confirm Error: " + errMsg.toString());
            }
        } catch (DocumentException | UnsupportedEncodingException e) {
            log.error("Error in changing order status.");
        }
    }
}
