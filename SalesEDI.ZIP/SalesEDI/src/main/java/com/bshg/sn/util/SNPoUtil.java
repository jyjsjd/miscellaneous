/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.sn.util;

import com.bshg.model.OrderItem;
import com.bshg.model.SalesOrder;
import com.bshg.util.DBUtil;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryResponse;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryResponse.OrderDetail;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryResponse.OrderHead;
import com.suning.api.entity.selfmarket.PurchaseOrderQueryResponse.PurchaseOrder;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 */
@Slf4j
public class SNPoUtil {

    public static Map<String, String> getRequestParamsMap(String bizParams) {
        Map<String, String> params = new HashMap<>();
        SAXReader reader = new SAXReader();

        try {
            Document doc = reader.read(new ByteArrayInputStream(bizParams.getBytes("UTF-8")));
            Element po = doc.getRootElement().element("sn_body").element("purchaseOrder");

            if (po != null) {
                for (Iterator iterator = po.elementIterator(); iterator.hasNext();) {
                    Element next = (Element) iterator.next();

                    switch (next.getQualifiedName()) {
                        case "orderCode":
                            params.put("orderCode", next.getStringValue());
                            break;
                        case "startDate":
                            params.put("startDate", next.getStringValue());
                            break;
                        case "endDate":
                            params.put("endDate", next.getStringValue());
                            break;
                        case "orderType":
                            params.put("orderType", next.getStringValue());
                            break;
                        case "orderStatus":
                            params.put("orderStatus", next.getStringValue());
                            break;
                        case "pageNo":
                            params.put("pageNo", next.getStringValue());
                            break;
                        case "pageSize":
                            params.put("pageSize", next.getStringValue());
                        default:
                            ;
                    }
                }
            }
        } catch (DocumentException | UnsupportedEncodingException ex) {
            log.error("Error in parsing XML files.");
        }

        return params;
    }

    public static void saveOrdersAndItems(String custCode, PurchaseOrderQueryResponse response) {
        List<SalesOrder> orders = new ArrayList<>();
        List<OrderItem> items = new ArrayList<>();

        for (PurchaseOrder order : response.getSnbody().getPurchaseOrder()) {
            OrderHead orderHead = order.getOrderHead();

            if (DBUtil.checkDupOrder(custCode, orderHead.getOrderCode())) {
                String synDate = (new DateTime()).toString(DateTimeFormat.forPattern("yyyy-MM-dd"));
                SalesOrder salesOrder = new SalesOrder(custCode, orderHead.getOrderCode(), orderHead.getOrderStatus(), null, new Date(), synDate, orderHead.getOrderType());
                orders.add(salesOrder);
            }

            for (OrderDetail item : order.getOrderDetail()) {
                if (DBUtil.checkDupItem(custCode, orderHead.getOrderCode(), item.getItemNo())) {
                    Date deliveryDate = new DateTime(
                            Integer.parseInt(item.getDeliveryDate().split("-")[0]), // year
                            Integer.parseInt(item.getDeliveryDate().split("-")[1]), // month 
                            Integer.parseInt(item.getDeliveryDate().split("-")[2]), // day
                            0, 0).toDate();
                    int orderedQty = (int) Float.parseFloat(item.getOrderQty());
                    
                    OrderItem orderItem = new OrderItem(custCode, orderHead.getOrderCode(), item.getItemNo(), item.getSupplierProductCode(),
                            orderedQty, orderedQty, new Date(), deliveryDate);
                    items.add(orderItem);
                }
            }
        }

        DBUtil.saveOrdersAndItems2DB(orders, items);
    }
}
