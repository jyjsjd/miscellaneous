/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.util;

import com.bshg.mapper.SalesOrderMapper;
import com.bshg.model.SalesOrder;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Properties;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author admjingya
 */
@Slf4j
public class SapUtil {

    private static final String RFCNOPOOL = "RFC_WITHOUT_POOL";
    private static final String FUNCTION = "/BSHS/SOM_SE_BIS_SYNC";
    private static final String TABLE = "CT_SEDIO";

    private static SqlSession session;

    static {
        Properties connectProperties = new Properties();
        connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, PropertyUtil.getValueByKey("JCO_ASHOST"));
        connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, PropertyUtil.getValueByKey("JCO_SYSNR"));
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, PropertyUtil.getValueByKey("JCO_CLIENT"));
        connectProperties.setProperty(DestinationDataProvider.JCO_USER, PropertyUtil.getValueByKey("JCO_USER"));
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, PropertyUtil.getValueByKey("JCO_PASSWD"));
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG, PropertyUtil.getValueByKey("JCO_LANG"));
        createDataFile(RFCNOPOOL, "jcoDestination", connectProperties);
    }

    private static void createDataFile(String name, String suffix, Properties properties) {
        File cfg = new File(name + "." + suffix);
        
        if (!cfg.exists()) {
            try {
                try (FileOutputStream fos = new FileOutputStream(cfg, false)) {
                    properties.store(fos, "");
                }
            } catch (Exception e) {
                EmailUtil.sendEmail("Scheduler API error",
                        "Unable to create the destination file " + cfg.getName());
            }
        }
    }

    public static void synOrderWithSap(String synDate) {
        try {
            session = MyBatisUtil.openSession();

            List<SalesOrder> ordersOfToday = session.getMapper(SalesOrderMapper.class).getOrdersByDate(synDate);

            if (ordersOfToday.size() > 0) {
                SapUtil.interactiveWithSap(ordersOfToday);
            } else {
                EmailUtil.sendEmail("Scheduler API info", "No orders to synchronize today.");
            }
        } catch (Exception e) {
            session.rollback();
            log.error("Error in synchronizing order status: " + e.getMessage());
            EmailUtil.sendEmail("Scheduler API error",
                    "Error in synchronizing order status: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    public static List<SalesOrder> interactiveWithSap(List<SalesOrder> ordersOfToday) {
        try {
            JCoDestination destination = JCoDestinationManager.getDestination(RFCNOPOOL);
            JCoFunction function = destination.getRepository().getFunction(FUNCTION);
            JCoTable table = function.getTableParameterList().getTable(TABLE);

            // add rows to table
            for (SalesOrder order : ordersOfToday) {
                String company;
                if ("SN".equals(order.getCompanyId())) {
                    company = "SUNING";
                } else {
                    company = order.getCompanyId();
                }

                table.appendRow();
                table.setValue("CUSTOMER_CODE", company);
                table.setValue("ORDER_CODE", order.getOrderNum());
            }

            // execute function in SAP
            function.execute(destination);
            if (table.getNumRows() > 0) {
                StringBuilder errMsg = new StringBuilder();
                errMsg.append("Order synchronize error. \n" + "Listed orders are not existed in SAP: ").append("\n\n");

                // remove the order from orders need to synchronize
                table.firstRow();

                for (int i = 0; i < table.getNumRows(); i++) {
                    table.setRow(i);

                    String orderNum = (String) table.getValue("ORDER_CODE");
                    for (SalesOrder order : ordersOfToday) {
                        if (order.getOrderNum().equals(orderNum)) {
                            ordersOfToday.remove(order);
                            break;
                        }
                    }
                    errMsg.append(orderNum).append("\n");
                }

                errMsg.append("\n").append(table.getNumRows()).append(" orders in total. ");

                // send warning email
                EmailUtil.sendEmail("Scheduler API error", errMsg.toString());
            }

            if (ordersOfToday.size() > 0) {
                DBUtil.updateOrderStatus2DB(ordersOfToday, "Sync");
            }
        } catch (JCoException e) {
            log.error("JCo error: " + e.getMessage());
            EmailUtil.sendEmail("Scheduler API error", e.getMessage());
        }
        return ordersOfToday;
    }
}
