package com.bshg.gome.util;

import com.bshg.util.PropertyUtil;

public class GOPConfig {

    public static final String APP_VERSION = "1.0"; // API version
    public static final String APP_URI_API = "/gopapi";// API URI
    public static final String APP_URI_ACCESSTOKEN = "/accessToken";// API URI to get accessToken
    public static final String APP_PROTOCOL = "https"; // API protocol
    
    public static String APP_KEY; // Application key
    public static String APP_SECRET; // Application secret
    public static String APP_URL; // Application URL
    public static int APP_PORT; // Port number
    public static String APP_ENV; //Environment sandbox or gopapi

    static {
        GOPConfig.APP_KEY = PropertyUtil.getValueByKey("GOME_APP_KEY");
        GOPConfig.APP_SECRET = PropertyUtil.getValueByKey("GOME_APP_SECRET");
        GOPConfig.APP_URL = PropertyUtil.getValueByKey("GOME_APP_URL");
        GOPConfig.APP_PORT = Integer.parseInt(PropertyUtil.getValueByKey("GOME_APP_PORT"));
        GOPConfig.APP_ENV = PropertyUtil.getValueByKey("GOME_APP_ENV");
    }
}
