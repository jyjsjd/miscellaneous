/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.gome.util;

import com.bshg.model.OrderItem;
import com.bshg.util.BSHFileUtil;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 *
 * @author admjingya
 */
@Slf4j
public class GomeXmlCreator {

    /**
     *
     * @param orderStatus "10" "30"
     */
    // This is for daily job
    public static void createOrderQueryXml(String orderStatus) {
        StringBuilder startTime = new StringBuilder();
        StringBuilder endTime = new StringBuilder();

        startTime.append(DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime().minusDays(1))).append(":21");
        endTime.append(DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime())).append(":23");

        Document orderQuery = DocumentHelper.createDocument();

        Element root = orderQuery.addElement("request");
        Element method = root.addElement("BU_ORDER_QUERY_PARAM");
        method.addElement("START_TIME").addText(startTime.toString());
        method.addElement("END_TIME").addText(endTime.toString());
        method.addElement("ORDER_STATUS").addText(orderStatus);

        BSHFileUtil.writeXml(orderQuery, "GOME", "PO");
    }

    // This is for orders more than 1 page.
    public static void createOrderQueryXml(Map<String, String> params) {
        Document orderInquiry = DocumentHelper.createDocument();

        Element root = orderInquiry.addElement("request");
        Element method = root.addElement("BU_ORDER_QUERY_PARAM");
        method.addElement("START_TIME").addText(params.get("START_TIME"));
        method.addElement("END_TIME").addText(params.get("END_TIME"));
        method.addElement("ORDER_STATUS").addText(params.get("ORDER_STATUS"));
        method.addElement("PAGE_NO").addText(params.get("PAGE_NO"));

        BSHFileUtil.writeXml(orderInquiry, "GOME", "PO");
    }

//    public static void createOrderConfirmXml(Map<String, List<OrderItem>> orders) {
//        Document orderConfirm = DocumentHelper.createDocument();
//
//        Element root = orderConfirm.addElement("request").addElement("BU_ORDER_CONFIRM_PARAM");
//
//        for (Map.Entry<String, List<OrderItem>> entry : orders.entrySet()) {
//            String orderNum = entry.getKey();
//            List<OrderItem> items = entry.getValue();
//            root.addElement("ORDER_CODE").addText(orderNum);
//            Element itemsElement = root.addElement("CONFIRM_ITEMS");
//
//            for (Iterator<OrderItem> iterator = items.iterator(); iterator.hasNext();) {
//                OrderItem item = iterator.next();
//
//                Element itemElement = itemsElement.addElement("ITEM");
//                itemElement.addElement("ORDER_ITEM_CODE").addText(item.getLineNum());
//                itemElement.addElement("MER_CODE").addText(item.getMerCode());
//                itemElement.addElement("AMOUNT").addText(String.valueOf(item.getQtyOrdered()));
//                itemElement.addElement("CONFIRM_AMOUNT").addText(String.valueOf(item.getQtyConfirmed()));
//            }
//        }
//        writeXml(orderConfirm, "CONFIRM");
//    }
    public static void createOrderConfirmXml(Map<String, List<OrderItem>> orders) {
        for (Map.Entry<String, List<OrderItem>> entry : orders.entrySet()) {
            Document orderConfirm = DocumentHelper.createDocument();
            Element root = orderConfirm.addElement("request").addElement("BU_ORDER_CONFIRM_PARAM");

            String orderNum = entry.getKey();
            List<OrderItem> items = entry.getValue();
            root.addElement("ORDER_CODE").addText(orderNum);
            Element itemsElement = root.addElement("CONFIRM_ITEMS");

            for (Iterator<OrderItem> iterator = items.iterator(); iterator.hasNext();) {
                OrderItem item = iterator.next();

                Element itemElement = itemsElement.addElement("ITEM");
                itemElement.addElement("ORDER_ITEM_CODE").addText(item.getLineNum());
                itemElement.addElement("MER_CODE").addText(item.getMerCode());
                itemElement.addElement("AMOUNT").addText(String.valueOf(item.getQtyOrdered()));
                itemElement.addElement("CONFIRM_AMOUNT").addText(String.valueOf(item.getQtyConfirmed()));
            }
            BSHFileUtil.writeXml(orderConfirm, "GOME", "CONFIRM");
        }
    }

    public static void createRetailInfo() {
        String createDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());

        Document salesInfo = DocumentHelper.createDocument();

        Element root = salesInfo.addElement("request");
        Element method = root.addElement("SALES_INFO_PARAM");
        method.addElement("CREATE_DATE").addText(createDate);

        BSHFileUtil.writeXml(salesInfo, "GOME", "RETAIL");
    }

    public static void createStockInfo() {
        String createDate = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());

        Document salesInfo = DocumentHelper.createDocument();

        Element root = salesInfo.addElement("request");
        Element method = root.addElement("STORE_INFO_PARAM");
        method.addElement("CREATE_DATE").addText(createDate);

        BSHFileUtil.writeXml(salesInfo, "GOME", "STOCK");
    }
}
