/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.mapper;

import com.bshg.model.SalesOrder;
import java.util.List;
import java.util.Map;

/**
 *
 * @author admjingya
 */
public interface SalesOrderMapper {

    SalesOrder getOrderByNum(Map params);
    
    List<SalesOrder> getOrdersByDate(String synDate);
    
    int insertOrder(SalesOrder order);

    void insertOrders(Map orders);

    int updateOrder(Map params);
}
