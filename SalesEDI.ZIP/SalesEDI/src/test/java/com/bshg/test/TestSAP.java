package com.bshg.test;

public class TestSAP {

//    @Test
//    public void testSyn() {
//
//        SapUtil.synOrderWithSap("2016-09-22");
//    }
}
