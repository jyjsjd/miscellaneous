/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.util;

/**
 *
 * @author admjingya
 */
import java.io.IOException;
import java.io.InputStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

@Slf4j
public class MyBatisUtil {

    private static SqlSessionFactory factory;

    static {
        try {
            InputStream is = Resources.getResourceAsStream("config/mybatis/mybatis-config-test.xml");
            if (factory == null) {
                factory = new SqlSessionFactoryBuilder().build(is);
            }
        } catch (IOException e) {
            log.error("Error in reading mybatis config file.");
        }
    }

    public static SqlSession openSession() {
        return factory.openSession();
    }

    public static void closeSession(SqlSession session) {
        if (session != null) {
            session.close();
        }
    }
}
