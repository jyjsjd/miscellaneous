package com.bshg.gome.util;

import com.bshg.util.EmailUtil;
import java.io.IOException;
import java.io.Serializable;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@XmlRootElement(name = "accessToken")
@XmlAccessorType(XmlAccessType.NONE)
@Slf4j
public class AccessToken implements Serializable {

    private static final long serialVersionUID = 1L;

    private static JAXBContext jaxbContext = null;
    private static Unmarshaller unmarshaller = null;
    private static volatile AccessToken token = null;

    static {
        try {
            jaxbContext = JAXBContext.newInstance(AccessToken.class);
            unmarshaller = jaxbContext.createUnmarshaller();
        } catch (Exception e) {
        }
    }

    @Getter
    @Setter
    @XmlElement(name = "status")
    private int status;
    @Getter
    @Setter
    @XmlElement(name = "access_token")
    private String accessToken;
    @Getter
    @Setter
    @XmlElement(name = "create_time")
    private Date createTime;
    @Getter
    @Setter
    @XmlElement(name = "expired_in")
    private Integer expiredIn;

    private AccessToken() {
    }

    public static synchronized AccessToken getInstance() {
        if (token != null) {
            if (longerThan2Hours(token.getCreateTime()) || token.getAccessToken() == null) {
                token = null;
                getInstance();
            }
        } else {
            String requesTime = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
            Map<String, String> params = new HashMap<>();

            params.put("req_time", requesTime);
            params.put("app_key", GOPConfig.APP_KEY);
            params.put("version", GOPConfig.APP_VERSION);
            params.put("sign", GOPSecurityUtil.md5sign(
                    requesTime + "|" + GOPConfig.APP_KEY + "|" + GOPConfig.APP_VERSION + "|" + GOPConfig.APP_SECRET));
            
            log.info("AccessToken request params: " + requesTime + "|" + GOPConfig.APP_KEY + "|" + GOPConfig.APP_VERSION + "|" + GOPConfig.APP_SECRET);
            
            try {
                String resultStr = GOPHttpPostHelper.invokeApi(GOPConfig.APP_PROTOCOL, GOPConfig.APP_URL,
                        GOPConfig.APP_PORT, GOPConfig.APP_ENV, GOPConfig.APP_URI_ACCESSTOKEN, params);
                token = (AccessToken) unmarshaller.unmarshal(new StringReader(resultStr));

                log.info("AccessToken string: " + resultStr);
            } catch (IOException | JAXBException e) {
                EmailUtil.sendEmail("Scheduler API error",
                        "Cannot get AccessToken: " + e.getMessage());
                log.error("Cannot get AccessToken: " + e.getMessage());
            }
        }
        return token;
    }

    private static boolean longerThan2Hours(Date createTime) {
        long diff = (new Date()).getTime() - createTime.getTime();
        double dayDiff = diff / (24 * 60 * 60 * 1000);
        double hourDiff = diff / (60 * 60 * 1000) - dayDiff * 24;

        // TODO if the time difference is more than one day
        return hourDiff * 60 >= token.getExpiredIn();
    }
}
