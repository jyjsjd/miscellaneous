/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bshg.test;

/**
 *
 * @author admjingya
 */
public class TestNormal {

//    @Test
//    public void testInt() {
//        System.out.println((int) Float.parseFloat("10.0000"));
//    }

//    @Test
//    public void testEmail() {
//        EmailUtil.sendEmail("info", "info");
//    }
}
